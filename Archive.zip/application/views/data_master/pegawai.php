<!--

=========================================================
* Volt Free - Bootstrap 5 Dashboard
=========================================================

* Product Page: https://themesberg.com/product/admin-dashboard/volt-bootstrap-5-dashboard
* Copyright 2021 Themesberg (https://www.themesberg.com)
* License (https://themesberg.com/licensing)

* Designed and coded by https://themesberg.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. Please contact us to request a removal.

-->
<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('header'); ?>

<body>

  <?php $this->load->view('sidebar'); ?>

  <!-- Main content -->
  <main class="content">

    <?php $this->load->view('navbar'); ?>

    <div class="row mt-5">
      <div class="col-12 col-xl-12">
        <div class="row">
          <div class="col-12 mb-4">
            <div class="card border-0 shadow">
              <div class="card-header">
                <div class="row align-items-center">
                  <div class="col">
                    <h2 class="fs-5 fw-bold mb-0"><?= isset($title) ? $title : 'Data' ?></h2>
                    <?php if ($this->session->flashdata('msg')) {
                      echo $this->session->flashdata('msg');
                    } ?>
                  </div>
                  <div class="col text-end">
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#modal-addPegawai"><i class="fa-solid fa-plus"></i> Pegawai</button>
                  </div>
                </div>
              </div>

              <div class="table-responsive py-4">
                <table class="table table-bordered table-striped" id="tabelPegawai" style="width: 100%;">
                  <thead class="thead-dark">
                    <tr>
                      <th>No</th>
                      <th>Nama</th>
                      <th>NIP</th>
                      <th>Golongan</th>
                      <th>Pangkat</th>
                      <th>Jabatan</th>
                      <th>Opsi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (isset($pegawai)) {
                      $no = 1;
                      foreach ($pegawai as $data) { ?>
                        <tr>
                          <td><?= $no++ ?></td>
                          <td><?= $data->nama ?></td>
                          <td><?= $data->nip ?></td>
                          <td><?= $data->golongan ?></td>
                          <td><?= $data->pangkat ?></td>
                          <td><?= $data->jabatan ?></td>
                          <td>
                            <a href="#" class="btn btn-sm btn-warning editPegawai" data-id="<?= $data->id_pegawai ?>" data-nama="<?= $data->nama ?>" data-nip="<?= $data->nip ?>" data-golongan="<?= $data->golongan ?>" data-pangkat="<?= $data->pangkat ?>" data-jabatan="<?= $data->jabatan ?>"><i class="fa fa-edit"></i></a>
                            <a href="#" class="btn btn-sm btn-danger deletePegawai" data-id="<?= $data->id_pegawai ?>" data-nama="<?= $data->nama ?>"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                    <?php }
                    } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

    <!-- Modal add pegawai -->
    <div class="modal fade" id="modal-addPegawai" role="dialog" aria-labelledby="modal-default" aria-hidden="true">
      <div class="modal-dialog modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h2 class="h6 modal-title">Tambah pegawai baru</h2>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <?= form_open('Data_master/proses_addPegawai') ?>
          <div class="modal-body">
            <div class="mb-3">
              <label for="nama" class="form-label">Nama</label>
              <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan nama" autofocus required>
            </div>
            <div class="mb-3">
              <label for="nip" class="form-label">NIP</label>
              <input type="text" class="form-control" id="nip" name="nip" placeholder="Masukkan NIP" required>
            </div>
            <div class="mb-3">
              <label for="golongan" class="form-label">Golongan</label>
              <input type="text" class="form-control" id="golongan" name="golongan" placeholder="Masukkan Golongan">
            </div>
            <div class="mb-3">
              <label for="pangkat" class="form-label">Pangkat</label>
              <input type="text" class="form-control" id="pangkat" name="pangkat" placeholder="Masukkan Pangkat">
            </div>
            <div class="mb-3">
              <label for="jabatan" class="form-label">Jabatan</label>
              <input type="text" class="form-control" id="jabatan" name="jabatan" placeholder="Masukkan Jabatan">
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn btn-link text-gray ms-auto" data-bs-dismiss="modal">Close</button>
          </div>
          <?= form_close() ?>

        </div>
      </div>
    </div>
    <!-- Modal add pegawai end -->

    <!-- Modal edit pegawai -->
    <div class="modal fade" id="modal-editPegawai" role="dialog" aria-labelledby="modal-default" aria-hidden="true">
      <div class="modal-dialog modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h2 class="h6 modal-title">Edit pegawai</h2>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <?= form_open('Data_master/proses_editPegawai') ?>
          <input type="hidden" class="form-control id_pegawai" id="id_pegawai" name="id_pegawai">
          <div class="modal-body">
            <div class="mb-3">
              <label for="nama" class="form-label">Nama</label>
              <input type="text" class="form-control nama" id="nama" name="nama" placeholder="Masukkan nama" autofocus required>
            </div>
            <div class="mb-3">
              <label for="nip" class="form-label">NIP</label>
              <input type="text" class="form-control nip" id="nip" name="nip" placeholder="Masukkan NIP" required>
            </div>
            <div class="mb-3">
              <label for="golongan" class="form-label">Golongan</label>
              <input type="text" class="form-control golongan" id="golongan" name="golongan" placeholder="Masukkan Golongan">
            </div>
            <div class="mb-3">
              <label for="pangkat" class="form-label">Pangkat</label>
              <input type="text" class="form-control pangkat" id="pangkat" name="pangkat" placeholder="Masukkan Pangkat">
            </div>
            <div class="mb-3">
              <label for="jabatan" class="form-label">Jabatan</label>
              <input type="text" class="form-control jabatan" id="jabatan" name="jabatan" placeholder="Masukkan Jabatan">
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-secondary">Update</button>
            <button type="button" class="btn btn-link text-gray ms-auto" data-bs-dismiss="modal">Close</button>
          </div>
          <?= form_close() ?>

        </div>
      </div>
    </div>
    <!-- Modal edit pegawai end -->

    <!-- Modal delete pegawai -->
    <div class="modal fade" id="modal-deletePegawai" role="dialog" aria-labelledby="modal-default" aria-hidden="true">
      <div class="modal-dialog modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h2 class="h6 modal-title">Hapus pegawai</h2>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <?= form_open('Data_master/proses_deletePegawai') ?>
          <div class="modal-body">
            <input type="hidden" class="form-control ID_pegawai" id="id_pegawai" name="id_pegawai">
            <span>Ingin menghapus data pegawai <b class="nama"></b> ?</span>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-danger">Hapus</button>
            <button type="button" class="btn btn-link text-gray ms-auto" data-bs-dismiss="modal">Close</button>
          </div>
          <?= form_close() ?>

        </div>
      </div>
    </div>
    <!-- Modal delete pegawai end -->


    <?php $this->load->view('data_master/footer'); ?>

</body>

</html>