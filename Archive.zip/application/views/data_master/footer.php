<footer class="bg-white rounded shadow p-5 mb-4 mt-4">
    <div class="row">
        <div class="col-12 col-md-4 col-xl-6 mb-4 mb-md-0">
            <p class="mb-0 text-center text-lg-start">© <span class="current-year"></span> <a class="text-primary fw-normal" href="#">BKSDA Kalsel</a></p>
        </div>
    </div>
</footer>
</main>

<!-- Core -->
<script src="<?= base_url() ?>/vendor/@popperjs/core/dist/umd/popper.min.js"></script>
<script src="<?= base_url() ?>/vendor/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Vendor JS -->
<script src="<?= base_url() ?>/vendor/onscreen/dist/on-screen.umd.min.js"></script>

<!-- Slider -->
<script src="<?= base_url() ?>/vendor/nouislider/distribute/nouislider.min.js"></script>

<!-- Smooth scroll -->
<script src="<?= base_url() ?>/vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>

<!-- Charts -->
<script src="<?= base_url() ?>/vendor/chartist/dist/chartist.min.js"></script>
<script src="<?= base_url() ?>/vendor/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>

<!-- Datepicker -->
<script src="<?= base_url() ?>/vendor/vanillajs-datepicker/dist/js/datepicker.min.js"></script>

<!-- Sweet Alerts 2 -->
<script src="<?= base_url() ?>/vendor/sweetalert2/dist/sweetalert2.all.min.js"></script>

<!-- Moment JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>

<!-- Vanilla JS Datepicker -->
<script src="<?= base_url() ?>/vendor/vanillajs-datepicker/dist/js/datepicker.min.js"></script>

<!-- Notyf -->
<script src="<?= base_url() ?>/vendor/notyf/notyf.min.js"></script>

<!-- Simplebar -->
<script src="<?= base_url() ?>/vendor/simplebar/dist/simplebar.min.js"></script>

<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>

<!-- Volt JS -->
<script src="<?= base_url() ?>/assets/js/volt.js"></script>

<!-- Font Awesome CDN -->
<script src="https://kit.fontawesome.com/d3ea3131f4.js" crossorigin="anonymous"></script>

<!-- Jquery -->
<script src="https://code.jquery.com/jquery-3.6.0.slim.js" integrity="sha256-HwWONEZrpuoh951cQD1ov2HUK5zA5DwJ1DNUXaM6FsY=" crossorigin="anonymous"></script>

<!-- Datatables -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>

<script>
    $(document).ready(function() {
        $('#tabelUser,#tabelPegawai,#tabelPK').DataTable({
            'scrollX': true,
        });

        //Modal edit user
        $('.editUser').on('click', function() {
            const id = $(this).data('id');
            const username = $(this).data('username');

            $('.id_user').val(id);
            $('.username').val(username);
            // Call Modal
            $('#modal-editUser').modal('show');
        });

        //Modal delete user
        $('.deleteUser').on('click', function() {
            const id = $(this).data('id');
            const username = $(this).data('username');

            $('.ID_user').val(id);
            $('.username').html(username);
            // Call Modal
            $('#modal-deleteUser').modal('show');
        });

        //Modal edit pegawai
        $('.editPegawai').on('click', function() {
            const id = $(this).data('id');
            const nama = $(this).data('nama');
            const nip = $(this).data('nip');
            const golongan = $(this).data('golongan');
            const pangkat = $(this).data('pangkat');
            const jabatan = $(this).data('jabatan');
            //console.log(id);

            $('.id_pegawai').val(id);
            $('.nama').val(nama);
            $('.nip').val(nip);
            $('.golongan').val(golongan);
            $('.pangkat').val(pangkat);
            $('.jabatan').val(jabatan);
            // Call Modal
            $('#modal-editPegawai').modal('show');
        });

        //Modal delete pegawai
        $('.deletePegawai').on('click', function() {
            const id = $(this).data('id');
            const nama = $(this).data('nama');

            $('.ID_pegawai').val(id);
            $('.nama').html(nama);
            // Call Modal
            $('#modal-deletePegawai').modal('show');
        });

        //Modal edit kegiatan
        $('.editKegiatan').on('click', function() {
            const id = $(this).data('id_kegiatan');
            const tahun = $(this).data('tahun_kegiatan');
            const nama = $(this).data('nama_kegiatan');

            $('.id_kegiatan').val(id);
            $('.tahunKegiatan').val(tahun);
            $('.kegiatan').val(nama);
            // Call Modal
            $('#modal-editKegiatan').modal('show');
        });

        //Modal delete kegiatan
        $('.deleteKegiatan').on('click', function() {
            const id = $(this).data('id_kegiatan');
            var nama = $(this).data('nama_kegiatan');

            $('.id_kegiatan').val(id);
            $('.nama_kegiatan').html(nama);
            // Call Modal
            $('#modal-deleteKegiatan').modal('show');
        });

        //Modal edit sasaran
        $('.editSasaran').on('click', function() {
            const id = $(this).data('id_sasaran');
            const nama = $(this).data('nama_sasaran');

            $('.id_sasaran').val(id);
            $('.sasaran').val(nama);
            // Call Modal
            $('#modal-editSasaran').modal('show');
        });

        //Modal delete sasaran
        $('.deleteSasaran').on('click', function() {
            const id = $(this).data('id_sasaran');
            const nama = $(this).data('nama_sasaran');

            $('.ID_sasaran').val(id);
            $('.sasaran').html(nama);
            // Call Modal
            $('#modal-deleteSasaran').modal('show');
        });

        //Modal add indikator
        $('.addIndikator').on('click', function() {
            const id = $(this).data('id_sasaran');
            const nama = $(this).data('nama_sasaran');

            $('.id_sasaran').val(id);
            $('.sasaran').html(nama);
            // Call Modal
            $('#modal-addIndikator').modal('show');
        });

        //Modal edit indikator
        $('.editIndikator').on('click', function() {
            const nama_sas = $(this).data('nama_sasaran');
            const id = $(this).data('id_indikator');
            const nama_ind = $(this).data('nama_indikator');

            $('.sasaran').html(nama_sas);
            $('.id_indikator').val(id);
            $('.indikator').val(nama_ind);
            // Call Modal
            $('#modal-editIndikator').modal('show');
        });

        //Modal delete indikator
        $('.deleteIndikator').on('click', function() {
            const id = $(this).data('id_indikator');
            const nama = $(this).data('nama_indikator');

            $('.ID_indikator').val(id);
            $('.indikator').html(nama);
            // Call Modal
            $('#modal-deleteIndikator').modal('show');
        });

        //Modal add RO
        $('.addRO').on('click', function() {
            const id_sasaran = $(this).data('id_sasaran');
            const id_indikator = $(this).data('id_indikator');
            const nama = $(this).data('nama_indikator');

            $('.id_sasaran').val(id_sasaran);
            $('.id_indikator').val(id_indikator);
            $('.indikator').html(nama);
            // Call Modal
            $('#modal-addRO').modal('show');
        });

        //Modal edit RO
        $('.editRO').on('click', function() {
            const nama_sas = $(this).data('nama_sasaran');
            const id_RO = $(this).data('id');
            const nama_RO = $(this).data('nama');

            $('.sasaran').html(nama_sas);
            $('.id_RO').val(id_RO);
            $('.nama_RO').val(nama_RO);
            // Call Modal
            $('#modal-editRO').modal('show');
        });

        //Modal delete RO
        $('.deleteRO').on('click', function() {
            const id_RO = $(this).data('id');
            const nama_RO = $(this).data('nama');

            $('.ID_RO').val(id_RO);
            $('.nama_RO').html(nama_RO);
            // Call Modal
            $('#modal-deleteRO').modal('show');
        });
    });
</script>