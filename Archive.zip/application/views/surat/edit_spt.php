<!--

=========================================================
* Volt Free - Bootstrap 5 Dashboard
=========================================================

* Product Page: https://themesberg.com/product/admin-dashboard/volt-bootstrap-5-dashboard
* Copyright 2021 Themesberg (https://www.themesberg.com)
* License (https://themesberg.com/licensing)

* Designed and coded by https://themesberg.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. Please contact us to request a removal.

-->
<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('header'); ?>

<body>

    <?php $this->load->view('sidebar'); ?>

    <!-- Main content -->
    <main class="content">

        <?php $this->load->view('navbar'); ?>

        <div class="row mt-5">
            <div class="col-12 col-xl-12">
                <div class="row">
                    <div class="col-12 mb-4">
                        <div class="card border-0 shadow">
                            <div class="card-header">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h2 class="fs-5 fw-bold mb-0"><?= isset($title) ? $title : 'Data' ?> (Edit)</h2>
                                        <?php if ($this->session->flashdata('msg')) {
                                            echo $this->session->flashdata('msg');
                                        } ?>
                                    </div>
                                </div>
                            </div>

                            <div class="card-body">
                                <?= form_open('Surat_tugas/proses_editSPT', '', ['id_surat' => $surat->id_surat]) ?>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label for="no_surat" class="form-label">Nomor</label>
                                        <input type="text" class="form-control" name="no_surat" id="no_surat" value="<?= isset($surat) ? $surat->no_surat : '' ?>" placeholder="ST/xx/xx/xx" required>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label for="dasar_surat" class="form-label">Dasar surat poin 4</label>
                                        <textarea class="form-control" name="dasar_surat" id="dasar_surat" placeholder="Isi dasar surat pada poin ke 4 bagian 'Dasar'" rows="5"><?= isset($surat) ? $surat->dasar_surat : '' ?></textarea>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label for="waktu" class="form-label">Waktu pelaksanaan</label>
                                        <textarea class="form-control" name="waktu" id="waktu" placeholder="Isi waktu pelaksanaan pada poin ke 2 bagian 'Untuk'" rows="5"><?= isset($surat) ? $surat->waktu : '' ?></textarea>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label for="sumber_dana" class="form-label">Sumber dana</label>
                                        <textarea class="form-control" name="sumber_dana" id="sumber_dana" placeholder="Isi sumber dana pada poin ke 4 bagian 'Untuk'" rows="5"><?= isset($surat) ? $surat->sumber_dana : '' ?></textarea>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label for="tgl_pelaksanaan" class="form-label">Tanggal Pelaksanaan</label>
                                        <input type="text" class="form-control" name="tgl_pelaksanaan[]" id="tgl_pelaksanaan" placeholder="Pilih tanggal pelaksanaan" multiple required value="<?php if (isset($tglPelaksanaan)) {
                                                                                                                                                                                                    foreach ($tglPelaksanaan as $data) {
                                                                                                                                                                                                        $date = date_create($data->tanggal);
                                                                                                                                                                                                        echo date_format($date, 'm/d/Y') . ',';
                                                                                                                                                                                                    }
                                                                                                                                                                                                } ?>">
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label for="mengetahui" class="form-label">Yang mengetahui</label>
                                        <select class="form-select" name="mengetahui" id="mengetahui" required>
                                            <?php foreach ($pegawai as $row) {
                                                echo "<option value='$row->id_pegawai'";
                                                echo $row->jabatan == 'Kepala Balai' ? 'selected' : '';
                                                echo ">$row->nama</option>";
                                            } ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12 mb-3">
                                        <label for="petugas" class="form-label">Petugas <div id='cek_jadwalPegawai'></div></label>
                                        <select class="form-select" name="petugas[]" id="petugas" multiple required>
                                            <?php foreach ($pegawai as $row) {
                                                echo "<option value='$row->id_pegawai'";
                                                if (isset($pegawaiTugas)) {
                                                    foreach ($pegawaiTugas as $pt) {
                                                        echo $pt->id_pegawai == $row->id_pegawai ? 'selected' : '';
                                                    }
                                                }
                                                echo ">$row->nama</option>";
                                            } ?>
                                        </select>
                                    </div>
                                </div>

                                <hr style="width: 100%;border-top:2px solid black">

                                <div class="row">
                                    <h6>Pilih Kegiatan</h6>
                                    <div class="col-12 mt-3 mb-5">
                                        <select class="form-select" name="kegiatan" id="kegiatan" required>
                                            <option disabled selected>-Pilih-</option>
                                            <?php foreach ($kegiatan as $row) {
                                                echo "<option value='$row->id_kegiatan'";
                                                echo $surat->kegiatan == $row->id_kegiatan ? 'selected' : '';
                                                echo ">$row->nama_kegiatan</option>";
                                            } ?>
                                        </select>
                                    </div>
                                </div>

                                <div id="hasil"></div>


                                <div class="text-center mt-3">
                                    <button type="submit" class="btn btn-warning">Update</button>
                                </div>

                                <?php form_close() ?>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>

        <?php $this->load->view('surat/footer'); ?>

</body>

</html>