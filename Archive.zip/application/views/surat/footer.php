<footer class="bg-white rounded shadow p-5 mb-4 mt-4">
    <div class="row">
        <div class="col-12 col-md-4 col-xl-6 mb-4 mb-md-0">
            <p class="mb-0 text-center text-lg-start">© <span class="current-year"></span> <a class="text-primary fw-normal" href="#">BKSDA Kalsel</a></p>
        </div>
    </div>
</footer>
</main>

<!-- Core -->
<script src="<?= base_url() ?>/vendor/@popperjs/core/dist/umd/popper.min.js"></script>
<script src="<?= base_url() ?>/vendor/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Vendor JS -->
<script src="<?= base_url() ?>/vendor/onscreen/dist/on-screen.umd.min.js"></script>

<!-- Slider -->
<script src="<?= base_url() ?>/vendor/nouislider/distribute/nouislider.min.js"></script>

<!-- Smooth scroll -->
<script src="<?= base_url() ?>/vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>

<!-- Charts -->
<script src="<?= base_url() ?>/vendor/chartist/dist/chartist.min.js"></script>
<script src="<?= base_url() ?>/vendor/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>

<!-- Datepicker -->
<script src="<?= base_url() ?>/vendor/vanillajs-datepicker/dist/js/datepicker.min.js"></script>

<!-- Sweet Alerts 2 -->
<script src="<?= base_url() ?>/vendor/sweetalert2/dist/sweetalert2.all.min.js"></script>

<!-- Moment JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>

<!-- Vanilla JS Datepicker -->
<script src="<?= base_url() ?>/vendor/vanillajs-datepicker/dist/js/datepicker.min.js"></script>

<!-- Notyf -->
<script src="<?= base_url() ?>/vendor/notyf/notyf.min.js"></script>

<!-- Simplebar -->
<script src="<?= base_url() ?>/vendor/simplebar/dist/simplebar.min.js"></script>

<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>

<!-- Volt JS -->
<script src="<?= base_url() ?>/assets/js/volt.js"></script>

<!-- Font Awesome CDN -->
<script src="https://kit.fontawesome.com/d3ea3131f4.js" crossorigin="anonymous"></script>

<!-- Jquery -->
<!-- <script src="https://code.jquery.com/jquery-3.6.0.slim.js" integrity="sha256-HwWONEZrpuoh951cQD1ov2HUK5zA5DwJ1DNUXaM6FsY=" crossorigin="anonymous"></script> -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<!-- Datatables -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>

<!-- Select 2 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<!-- Date picker -->
<script src="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>

<script>
    $(document).ready(function() {
        $('#tabelSurat').DataTable({
            'scrollX': true,
        });

        $('#kegiatan,#petugas').select2({
            theme: "bootstrap-5",
            width: '100%',
            placeholder: '-Pilih-'
        });

        $('#tgl_pelaksanaan').datepicker({
            multidate: true
        });

        $('#kegiatan').change(function() {
            var kegiatan = $("#kegiatan").val()
            $.ajax({
                url: "<?= base_url('Surat_tugas/show_opsiKegiatan') ?>",
                method: "POST",
                data: {
                    kegiatan: kegiatan
                },
                success: function(data) {
                    console.log(data);
                    $("#hasil").html(data)
                }
            })
        })

        //Modal upload surat fix
        $('.uploadSurat').on('click', function() {
            const id = $(this).data('id');
            const kegiatan = $(this).data('kegiatan');

            $('.id_surat').val(id);
            $('.kegiatan').html(kegiatan);
            // Call Modal
            $('#modal-uploadSurat').modal('show');
        });

        //Modal delete surat
        $('.deleteSPT').on('click', function() {
            const id = $(this).data('id');
            const kegiatan = $(this).data('kegiatan');

            $('.id_surat').val(id);
            $('.kegiatan').html(kegiatan);
            // Call Modal
            $('#modal-deleteSurat').modal('show');
        });

        //Cek petugas jika bentrok
        $('#petugas').change(function() {
            var selected = [];
            for (var option of document.getElementById('petugas').options) {
                if (option.selected) {
                    selected.push(option.value);
                }
            }

            var tgl_pelaksanaan = $("#tgl_pelaksanaan").val()
            // console.log(selected);
            // console.log(tgl_pelaksanaan);
            $.ajax({
                url: "<?= base_url('Surat_tugas/cek_petugas') ?>",
                method: "POST",
                data: {
                    petugas: selected,
                    tgl_pelaksanaan: tgl_pelaksanaan
                },
                success: function(data) {
                    console.log(data);
                    $('#cek_jadwalPegawai').html(data);
                }
            })
        })
    });
</script>