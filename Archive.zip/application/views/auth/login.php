<!--

=========================================================
* Volt Pro - Premium Bootstrap 5 Dashboard
=========================================================

* Product Page: https://themesberg.com/product/admin-dashboard/volt-bootstrap-5-dashboard
* Copyright 2021 Themesberg (https://www.themesberg.com)
* License (https://themes.getbootstrap.com/licenses/)

* Designed and coded by https://themesberg.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. Please contact us to request a removal.

-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <!-- Primary Meta Tags -->
    <title>BKSDA | Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="title" content="Website SPT BKSDA Kalsel - Login">
    <meta name="author" content="BKSDA">
    <meta name="description" content="Website pembuatan surat perintah tugas untuk pegawai di lingkungan BKSDA Kalsel">
    <meta name="keywords" content="SPT, PK, Surat" />
    <!-- <link rel="canonical" href="https://themesberg.com/product/admin-dashboard/volt-premium-bootstrap-5-dashboard"> -->

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="120x120" href="<?= base_url() ?>assets/img/favicon/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/assets/img/favicon/logo.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url() ?>/assets/img/favicon/logo.png">
    <link rel="manifest" href="<?= base_url() ?>/assets/img/favicon/site.webmanifest">
    <link rel="mask-icon" href="<?= base_url() ?>/assets/img/favicon/safari-pinned-tab.svg" color="#ffffff">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">

    <!-- Sweet Alert -->
    <link type="text/css" href="<?= base_url() ?>/vendor/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">

    <!-- Notyf -->
    <link type="text/css" href="<?= base_url() ?>/vendor/notyf/notyf.min.css" rel="stylesheet">

    <!-- Volt CSS -->
    <link type="text/css" href="<?= base_url() ?>/assets/css/volt.css" rel="stylesheet">

    <!-- Font Awesome 6 -->
    <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

</head>

<body>

    <main class="bg-login">

        <!-- Section -->
        <section class="vh-lg-100 mt-5 mt-lg-0 bg-soft d-flex align-items-center">
            <div class="container">
                <div class="row justify-content-center form-bg-image">
                    <div class="col-12 d-flex align-items-center justify-content-center">
                        <div class="bg-white bg-opacity-75 shadow border-0 rounded border-light p-4 p-lg-5 w-100 fmxw-500">
                            <div class="text-center text-md-center mb-4 mt-md-0">
                                <img src="<?= base_url('assets/img/favicon/logo.png') ?>" height="80px">
                                <h6>Surat Perintah Tugas</h6>
                                <h6>BKSDA Kalimantan Selatan</h6>
                            </div>
                            <form action="<?= base_url('Auth/login_authentication') ?>" class="mt-4" method="post">
                                <!-- Form -->
                                <div class="form-group mb-4">
                                    <label for="username">Username</label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon1">
                                            <span class="fa fa-user"></span>
                                        </span>
                                        <input type="username" class="form-control" placeholder="Masukkan Username" id="username" name="username" autofocus required>

                                    </div>
                                </div>
                                <!-- End of Form -->
                                <div class="form-group">
                                    <!-- Form -->
                                    <div class="form-group mb-4">
                                        <label for="password">Password</label>
                                        <div class="input-group">
                                            <span class="input-group-text" id="basic-addon2">
                                                <i class="fa fa-lock"></i>
                                            </span>
                                            <input type="password" placeholder="Masukkan Password" class="form-control" id="password" name="password" required>
                                        </div>
                                    </div>
                                    <!-- End of Form -->
                                </div>
                                <?php if ($this->session->flashdata('msg')) {
                                    echo '<p style="font-size:12pt;color:red;text-align:center">' . $this->session->flashdata('msg') . '</p>';
                                } ?>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-gray-800">Login</button>
                                </div>
                            </form>

                            <!-- <div class="d-flex justify-content-center align-items-center mt-4">
                                <span class="fw-normal">
                                    Not registered?
                                    <a href="./sign-up.html" class="fw-bold">Create account</a>
                                </span>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Core -->
    <script src="<?= base_url() ?>/vendor/@popperjs/core/dist/umd/popper.min.js"></script>
    <script src="<?= base_url() ?>/vendor/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Vendor JS -->
    <script src="<?= base_url() ?>/vendor/onscreen/dist/on-screen.umd.min.js"></script>

    <!-- Slider -->
    <script src="<?= base_url() ?>/vendor/nouislider/distribute/nouislider.min.js"></script>

    <!-- Smooth scroll -->
    <script src="<?= base_url() ?>/vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>

    <!-- Charts -->
    <script src="<?= base_url() ?>/vendor/chartist/dist/chartist.min.js"></script>
    <script src="<?= base_url() ?>/vendor/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>

    <!-- Datepicker -->
    <script src="<?= base_url() ?>/vendor/vanillajs-datepicker/dist/js/datepicker.min.js"></script>

    <!-- Sweet Alerts 2 -->
    <script src="<?= base_url() ?>/vendor/sweetalert2/dist/sweetalert2.all.min.js"></script>

    <!-- Moment JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>

    <!-- Vanilla JS Datepicker -->
    <script src="<?= base_url() ?>/vendor/vanillajs-datepicker/dist/js/datepicker.min.js"></script>

    <!-- Notyf -->
    <script src="<?= base_url() ?>/vendor/notyf/notyf.min.js"></script>

    <!-- Simplebar -->
    <script src="<?= base_url() ?>/vendor/simplebar/dist/simplebar.min.js"></script>

    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>

    <!-- Volt JS -->
    <script src="<?= base_url() ?>/assets/js/volt.js"></script>


</body>

</html>