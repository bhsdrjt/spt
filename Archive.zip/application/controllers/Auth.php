<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('M_auth');
        $this->CI = &get_instance();
    }

    function index()
    {
        $this->load->view('auth/login');
    }

    function login_authentication()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $cekUser = $this->db->get_where('user', ['username' => $username])->row();

        if ($cekUser) {
            $pass = $cekUser->password;
            $verify_pass = password_verify($password, $pass);
            if ($verify_pass) {
                $data_session = array(
                    'id_user' => $cekUser->id,
                    'username' => $username,
                    'status' => "is_login",
                );
                $this->M_auth->update_last_login($cekUser->id);
                $this->session->set_userdata($data_session);
                redirect('Data_master/user');
            } else {
                $this->CI->session->set_flashdata('msg', 'Password salah !');
                redirect('Auth', 'refresh');
            }
        } else {
            $this->CI->session->set_flashdata('msg', 'Username tidak ditemukan !');
            redirect('Auth', 'refresh');
        }
    }

    function logout()
    {
        $this->session->sess_destroy();
        redirect('Auth', 'refresh');
    }
}
