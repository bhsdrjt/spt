<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_master extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('status') != "is_login") {
            redirect(base_url("Auth"));
        }
        $this->load->model('M_data_master');
    }

    public function user()
    {
        $data = [
            'title' => 'Data User',
            'user' => $this->db->get('user')->result()
        ];
        $this->load->view('data_master/user', $data);
    }

    public function proses_addUser()
    {
        $username = $this->input->post('username');
        $password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);

        $data = ['username' => $username, 'password' => $password, 'created_at' => date('Y-m-d H:i:s')];
        $simpan = $this->db->insert('user', $data);
        if ($simpan) {
            $this->session->set_flashdata('msg', '<div class="badge bg-success">Data user ditambahkan</div>');
        } else {
            $this->session->set_flashdata('msg', '<div class="badge bg-warning">Data user gagal ditambahkan</div>');
        }
        redirect('Data_master/user');
    }

    public function proses_editUser()
    {
        $id_user = $this->input->post('id_user');
        $username = $this->input->post('username');
        $password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);

        $data = ['username' => $username, 'password' => $password, 'modified_at' => date('Y-m-d H:i:s')];
        $edit = $this->db->update('user', $data, ['id' => $id_user]);
        if ($edit) {
            $this->session->set_flashdata('msg', '<div class="badge bg-success">Data user diupdate</div>');
        } else {
            $this->session->set_flashdata('msg', '<div class="badge bg-warning">Data user gagal diupdate</div>');
        }
        redirect('Data_master/user');
    }

    public function proses_deleteUser()
    {
        $id_user = $this->input->post('id_user');
        $hapus = $this->db->delete('user', ['id' => $id_user]);
        if ($hapus) {
            $this->session->set_flashdata('msg', '<div class="badge bg-success">Data user dihapus</div>');
        } else {
            $this->session->set_flashdata('msg', '<div class="badge bg-warning">Data user gagal dihapus</div>');
        }
        redirect('Data_master/user');
    }

    public function pegawai()
    {
        $data = [
            'title' => 'Data Pegawai',
            'pegawai' => $this->db->get('pegawai')->result()
        ];
        $this->load->view('data_master/pegawai', $data);
    }

    public function proses_addPegawai()
    {
        $nama = $this->input->post('nama');
        $nip = $this->input->post('nip');
        $golongan = $this->input->post('golongan');
        $pangkat = $this->input->post('pangkat');
        $jabatan = $this->input->post('jabatan');

        $data = ['nama' => $nama, 'nip' => $nip, 'golongan' => $golongan, 'pangkat' => $pangkat, 'jabatan' => $jabatan, 'created_at' => date('Y-m-d H:i:s'), 'user_input' => $_SESSION['username'],];
        $simpan = $this->db->insert('pegawai', $data);
        if ($simpan) {
            $this->session->set_flashdata('msg', '<div class="badge bg-success">Data pegawai ditambahkan</div>');
        } else {
            $this->session->set_flashdata('msg', '<div class="badge bg-warning">Data pegawai gagal ditambahkan</div>');
        }
        redirect('Data_master/pegawai');
    }

    public function proses_editPegawai()
    {
        $id_pegawai = $this->input->post('id_pegawai');
        $nama = $this->input->post('nama');
        $nip = $this->input->post('nip');
        $golongan = $this->input->post('golongan');
        $pangkat = $this->input->post('pangkat');
        $jabatan = $this->input->post('jabatan');

        $data = ['nama' => $nama, 'nip' => $nip, 'golongan' => $golongan, 'pangkat' => $pangkat, 'jabatan' => $jabatan, 'modified_at' => date('Y-m-d H:i:s'), 'user_input' => $_SESSION['username'],];
        $edit = $this->db->update('pegawai', $data, ['id_pegawai' => $id_pegawai]);
        if ($edit) {
            $this->session->set_flashdata('msg', '<div class="badge bg-success">Data pegawai diupdate</div>');
        } else {
            $this->session->set_flashdata('msg', '<div class="badge bg-warning">Data pegawai gagal diupdate</div>');
        }
        redirect('Data_master/pegawai');
    }

    public function proses_deletePegawai()
    {
        $id_pegawai = $this->input->post('id_pegawai');
        $hapus = $this->db->delete('pegawai', ['id_pegawai' => $id_pegawai]);
        if ($hapus) {
            $this->session->set_flashdata('msg', '<div class="badge bg-success">Data pegawai dihapus</div>');
        } else {
            $this->session->set_flashdata('msg', '<div class="badge bg-warning">Data pegawai gagal dihapus</div>');
        }
        redirect('Data_master/pegawai');
    }

    public function perjanjian_kinerja()
    {
        $data['title'] = 'Data Perjanjian Kinerja';
        $tahun = $this->input->post('tahun');
        if (isset($tahun)) {
            $tahunActive = $tahun;
        } else {
            $tahunActive = date('Y');
        };
        $data['tahunActive'] = $tahunActive;
        $data['tahunTersedia'] = $this->db->query('SELECT tahun FROM kegiatan GROUP BY tahun')->result();
        $data['pk'] = $this->M_data_master->perjanjian_kinerja($tahunActive);
        $this->load->view('data_master/perjanjian_kinerja', $data);
    }

    public function proses_addKegiatan()
    {
        $tahunKegiatan = $this->input->post('tahunKegiatan');
        $kegiatan = $this->input->post('kegiatan');
        $data = [
            'nama_kegiatan' => $kegiatan,
            'tahun' => $tahunKegiatan,
            'created_at' => date('Y-m-d H:i:s'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->insert('kegiatan', $data);
        redirect('Data_master/perjanjian_kinerja');
    }

    public function proses_editKegiatan()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $tahunKegiatan = $this->input->post('tahunKegiatan');
        $kegiatan = $this->input->post('kegiatan');
        $data = [
            'nama_kegiatan' => $kegiatan,
            'tahun' => $tahunKegiatan,
            'modified_at' => date('Y-m-d H:i:s'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->update('kegiatan', $data, ['id_kegiatan' => $id_kegiatan]);
        redirect('Data_master/perjanjian_kinerja');
    }

    public function proses_deleteKegiatan()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        //Hapus ditabel kegiatan
        $this->db->delete('kegiatan', ['id_kegiatan' => $id_kegiatan]);

        //Hapus ditabel sasaran
        $this->db->delete('sasaran', ['id_kegiatan' => $id_kegiatan]);

        //Hapus ditabel kegiatan
        $this->db->delete('indikator', ['id_kegiatan' => $id_kegiatan]);

        //Hapus ditabel ro
        $this->db->delete('ro', ['id_kegiatan' => $id_kegiatan]);
        redirect('Data_master/perjanjian_kinerja');
    }

    public function detail_kegiatan($id)
    {
        $data = [
            'title' => 'Data Perjanjian Kinerja',
            'kegiatan' => $this->db->get_where('kegiatan', ['id_kegiatan' => $id])->row(), //Get data kegiatan
            'sasaran' => $this->db->get_where('sasaran', ['id_kegiatan' => $id])->result()
        ];
        $this->load->view('data_master/detail_kegiatan', $data);
    }

    public function proses_addSasaran()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $sasaran = $this->input->post('sasaran');
        $data = [
            'id_kegiatan' => $id_kegiatan,
            'nama_sasaran' => $sasaran,
            'created_at' => date('Y-m-d H:i:s'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->insert('sasaran', $data);
        redirect('Data_master/detail_kegiatan/' . $id_kegiatan);
    }

    public function proses_editSasaran()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $id_sasaran = $this->input->post('id_sasaran');
        $sasaran = $this->input->post('sasaran');
        $data = [
            'nama_sasaran' => $sasaran,
            'modified_at' => date('Y-m-d H:i:s'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->update('sasaran', $data, ['id_sasaran' => $id_sasaran]);
        redirect('Data_master/detail_kegiatan/' . $id_kegiatan);
    }

    public function proses_deleteSasaran()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $id_sasaran = $this->input->post('id_sasaran');

        //Hapus ditabel sasaran
        $this->db->delete('sasaran', ['id_sasaran' => $id_sasaran]);

        //Hapus ditabel indikator
        $this->db->delete('indikator', ['id_sasaran' => $id_sasaran]);

        //Hapus ditabel ro
        $this->db->delete('ro', ['id_sasaran' => $id_sasaran]);
        redirect('Data_master/detail_kegiatan/' . $id_kegiatan);
    }

    public function proses_addIndikator()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $id_sasaran = $this->input->post('id_sasaran');
        $indikator = $this->input->post('indikator');
        $data = [
            'id_kegiatan' => $id_kegiatan,
            'id_sasaran' => $id_sasaran,
            'nama_indikator' => $indikator,
            'created_at' => date('Y-m-d H:i:s'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->insert('indikator', $data);
        redirect('Data_master/detail_kegiatan/' . $id_kegiatan);
    }

    public function proses_editIndikator()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $id_indikator = $this->input->post('id_indikator');
        $indikator = $this->input->post('indikator');
        $data = [
            'nama_indikator' => $indikator,
            'modified_at' => date('Y-m-d H:i:s'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->update('indikator', $data, ['id_indikator' => $id_indikator]);
        redirect('Data_master/detail_kegiatan/' . $id_kegiatan);
    }

    public function proses_deleteIndikator()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $id_indikator = $this->input->post('id_indikator');

        //Hapus ditabel indikator
        $this->db->delete('indikator', ['id_indikator' => $id_indikator]);

        //Hapus ditabel ro
        $this->db->delete('ro', ['id_indikator' => $id_indikator]);
        redirect('Data_master/detail_kegiatan/' . $id_kegiatan);
    }

    public function proses_addRO()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $id_sasaran = $this->input->post('id_sasaran');
        $id_indikator = $this->input->post('id_indikator');
        $rincian_output = $this->input->post('rincian_output');
        $data = [
            'id_kegiatan' => $id_kegiatan,
            'id_sasaran' => $id_sasaran,
            'id_indikator' => $id_indikator,
            'nama_ro' => $rincian_output,
            'created_at' => date('Y-m-d H:i:s'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->insert('ro', $data);
        redirect('Data_master/detail_kegiatan/' . $id_kegiatan);
    }

    public function proses_editRO()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $id_RO = $this->input->post('id_RO');
        $nama_RO = $this->input->post('nama_RO');

        $data = [
            'nama_ro' => $nama_RO,
            'modified_at' => date('Y-m-d H:i:s'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->update('ro', $data, ['id_ro' => $id_RO]);
        redirect('Data_master/detail_kegiatan/' . $id_kegiatan);
    }

    public function proses_deleteRO()
    {
        $id_kegiatan = $this->input->post('id_kegiatan');
        $id_RO = $this->input->post('id_RO');

        //Hapus ditabel ro
        $this->db->delete('ro', ['id_ro' => $id_RO]);
        redirect('Data_master/detail_kegiatan/' . $id_kegiatan);
    }
}
