<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Surat_tugas extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('status') != "is_login") {
            redirect(base_url("Auth"));
        }
        $this->load->model('M_surat_tugas');
    }

    public function index()
    {
        $data['title'] = 'Surat Perintah Tugas';
        $data['surat'] = $this->M_surat_tugas->surat_tugas();
        $this->load->view('surat/spt', $data);
    }

    public function add_spt()
    {
        $data['title'] = 'Surat Perintah Tugas';
        $data['kegiatan'] = $this->db->get_where('kegiatan')->result();
        $data['pegawai'] = $this->db->get_where('pegawai')->result();
        $this->load->view('surat/tambah_spt', $data);
    }

    function show_opsiKegiatan()
    {
        $kegiatan = $this->input->post('kegiatan');
        //Get Sasaran kegiatan
        $sasaran = $this->db->get_where('sasaran', ['id_kegiatan' => $kegiatan])->result();
        //Get Indikator kegiatan
        $indikator = $this->db->get_where('indikator', ['id_kegiatan' => $kegiatan])->result();
        //Get RO kegiatan
        $ro = $this->db->get_where('ro', ['id_kegiatan' => $kegiatan])->result();

        $output = "";
        $index = 0;
        $output .= '<div class="row">';
        // Sasaran kegiatan
        if (!empty($sasaran)) {
            $output .= '<div class="col-4"><div class="alert alert-info" role="alert"><b>Sasaran Kegiatan</b></div>';
            foreach ($sasaran as $sas) {
                $output .= '<div class="form-check">
            <input class="form-check-input" type="radio" value="' . $sas->id_sasaran . '" name="sasaran" id="sasaran' . $index++ . '">
            <label class="form-check-label" for="sasaran' . $index++ . '">
                ' . $sas->nama_sasaran . '
            </label>
        </div>';
            }
            $output .= '</div>';
        }

        // Indikator kegiatan
        if (!empty($indikator)) {
            $output .= '<div class="col-4"><div class="alert alert-secondary" role="alert"><b>Indikator Kegiatan</b></div>';
            foreach ($indikator as $ind) {
                $output .= '<div class="form-check">
            <input class="form-check-input" type="radio" value="' . $ind->id_sasaran . '" name="indikator" id="indikator' . $index++ . '">
            <label class="form-check-label" for="indikator' . $index++ . '">
                ' . $ind->nama_indikator . '
            </label>
        </div>';
            }
            $output .= '</div>';
        }

        // Rincian output kegiatan
        if (!empty($ro)) {
            $output .= '<div class="col-4"><div class="alert alert-warning" role="alert"><b>Rincian Output</b></div>';
            foreach ($ro as $r) {
                $output .= '<div class="form-check">
            <input class="form-check-input" type="radio" value="' . $r->id_ro . '" name="rincian_output" id="rincian_output' . $index++ . '">
            <label class="form-check-label" for="rincian_output' . $index++ . '">
                ' . $r->nama_ro . '
            </label>
        </div>';
            }
            $output .= '</div>';
        }
        $output .= '</div>';
        echo $output;
    }

    public function proses_addSPT()
    {
        $no_surat = $this->input->post('no_surat');
        $dasar_surat = $this->input->post('dasar_surat');
        $kegiatan = $this->input->post('kegiatan');
        $sasaran = $this->input->post('sasaran');
        $indikator = $this->input->post('indikator');
        $rincian_output = $this->input->post('rincian_output');
        $waktu = $this->input->post('waktu');
        $sumber_dana = $this->input->post('sumber_dana');
        $mengetahui = $this->input->post('mengetahui');

        $data = [
            'no_surat' => $no_surat,
            'dasar_surat' => $dasar_surat,
            'kegiatan' => $kegiatan,
            'sasaran' => $sasaran,
            'indikator' => $indikator,
            'rincian_output' => $rincian_output,
            'waktu' => $waktu,
            'sumber_dana' => $sumber_dana,
            'mengetahui' => $mengetahui,
            'created_at' => date('Y-m-d'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->insert('surat', $data);
        $id_surat = $this->db->insert_id();

        $tgl = $this->input->post('tgl_pelaksanaan');
        $tgl2 = implode(',', $tgl); //Pecah dulu array menjadi string karena arraynya kacau
        $tgl3 = explode(',', $tgl2); //Pecah dari string menjadi array

        for ($i = 0; $i < COUNT($tgl3); $i++) {
            $tgl_pelaksanaan = date('Y-m-d', strtotime($tgl3[$i])); //Ubah menjadi format Y-m-d

            $dataTanggal = [
                'id_surat' => $id_surat,
                'tanggal' => $tgl_pelaksanaan,
            ];
            $this->db->insert('tgl_pelaksanaan', $dataTanggal);
        }

        $petugas = $this->input->post('petugas');
        for ($i = 0; $i < COUNT($petugas); $i++) {

            $dataPegawai = [
                'id_surat' => $id_surat,
                'id_pegawai' => $petugas[$i],
            ];
            $this->db->insert('pegawai_tugas', $dataPegawai);
        }
        redirect('Surat_tugas');
    }

    public function cek_petugas()
    {
        $petugas = $this->input->post('petugas');
        $id_petugas = $petugas[count($petugas) - 1];
        $tgl = array($this->input->post('tgl_pelaksanaan'));
        //$tgl = array('03/30/2022,03/31/2022,04/01/202');
        $tgl2 = implode(',', $tgl); //Pecah dulu array menjadi string karena arraynya kacau
        $tgl3 = explode(',', $tgl2); //Pecah dari string menjadi array

        $hasil = 0;
        for ($i = 0; $i < COUNT($tgl3); $i++) {
            $tgl_pelaksanaan = date('Y-m-d', strtotime($tgl3[$i])); //Ubah menjadi format Y-m-d
            $cek = $this->db->query('SELECT * FROM tgl_pelaksanaan tp JOIN surat ON surat.id_surat=tp.id_surat JOIN pegawai_tugas pt ON pt.id_surat=surat.id_surat JOIN pegawai ON pegawai.id_pegawai=pt.id_pegawai JOIN kegiatan ON kegiatan.id_kegiatan=surat.kegiatan  WHERE pt.id_pegawai=' . $id_petugas . ' AND tp.tanggal="' . $tgl_pelaksanaan . '"')->row();
            if ($cek) {
                $hasil++;
                $tanggal_perPegawai[$i] = $cek->tanggal;
                $nama_pegawai = $cek->nama;
                $kegiatan = $cek->nama_kegiatan;
            }
        }

        if ($hasil != 0) {
            $tanggal_view = implode(', ', $tanggal_perPegawai);
            echo '<span class="badge bg-danger text-dark">' . $nama_pegawai . ' ada kegiatan ' . $kegiatan . ' pada tanggal ' . $tanggal_view . '</span>';
        }
        // echo $hasil;
        // var_dump($tanggal_perPegawai);
    }

    public function cetak_surat($id)
    {
        $data['title'] = 'Surat Perintah Tugas';
        $data['surat'] = $this->M_surat_tugas->cetak_surat($id);
        $data['pegawaiTugas'] = $this->M_surat_tugas->pegawai_tugas($id);
        //var_dump(($data['pegawaiTugas']));
        $this->load->view('surat/cetak_surat', $data);
    }

    public function proses_uploadSurat()
    {
        $id_surat = $this->input->post('id_surat');
        $get_fileSurat = $this->db->query('SELECT file_surat FROM surat WHERE id_surat=' . $id_surat)->row();
        if (!empty($get_fileSurat->file_surat)) {
            unlink("./assets/uploads/$get_fileSurat->file_surat");
        }

        if (!empty($_FILES['file_surat']['name'])) {
            //Pengecekan ukuran file
            if ($_FILES['file_surat']['size'] > 3485760) { // 3MB 
                $this->session->set_flashdata('message', '<span class="badge bg-danger text-dark">Ukuran file max 3MB</span>');
                var_dump($_FILES['file_surat']['size']);
                redirect('Surat_tugas');
            }

            //Pengecekan extensi file jika benar maka lolos untuk diproses
            $ext = substr(strrchr($_FILES['file_surat']['name'], '.'), 1);
            if ($ext == 'pdf' || $ext == 'doc' || $ext == 'docx' || $ext == 'jpg' || $ext == 'jpeg' || $ext == 'png') {
                $upload = $this->_do_upload();
                $data['file_surat'] = $upload['file_name'];

                // Simpan datanya ke database
                $data = array('file_surat' => $data['file_surat']);
                $this->db->update('surat', $data, ['id_surat' => $id_surat]);
            } else {
                $this->session->set_flashdata('message', '<span class="badge bg-danger text-dark">Ekstensi file harus berupa pdf/doc/docx/jpg/jpeg/png</span>');
                redirect('Surat_tugas');
            }
        } else {
            $data['file_surat'] = "";
        }
        redirect('Surat_tugas');
    }

    private function _do_upload()
    {
        $config['upload_path']      = './assets/uploads/';
        $config['allowed_types']    = 'jpeg|jpg|png|pdf|doc|docx';
        $config['max_size']             = 3048;
        $config['overwrite']            = true;
        $config['file_name']            = uniqid();

        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('file_surat')) {
            $this->session->set_flashdata('message', '<span class="badge bg-danger text-dark">Harap periksa eksistensi file/ukuran file</span>');
            redirect('Surat_tugas');
        }
        return $this->upload->data();
    }

    public function proses_deleteSurat()
    {
        $id_surat = $this->input->post('id_surat');

        //Hapus file lebih dulu
        $get_fileSurat = $this->db->query('SELECT file_surat FROM surat WHERE id_surat=' . $id_surat)->row();
        if (!empty($get_fileSurat->file_surat)) {
            unlink("./assets/uploads/$get_fileSurat->file_surat");
        }

        //Hapus data di tabel
        $hapus = $this->db->delete('surat', ['id_surat' => $id_surat]);
        $this->db->delete('pegawai_tugas', ['id_surat' => $id_surat]);
        $this->db->delete('tgl_pelaksanaan', ['id_surat' => $id_surat]);
        if ($hapus) {
            $this->session->set_flashdata('message', '<span class="badge bg-success">Surat berhasil dihapus</span>');
        } else {
            $this->session->set_flashdata('message', '<span class="badge bg-danger">Surat gagal dihapus</span>');
        }
        redirect('Surat_tugas');
    }

    public function edit_spt($id_surat)
    {
        $data['title'] = 'Surat Perintah Tugas';
        $data['kegiatan'] = $this->db->get_where('kegiatan')->result();
        $data['pegawai'] = $this->db->get_where('pegawai')->result();

        $data['surat'] = $this->M_surat_tugas->surat_tugas($id_surat);
        $data['pegawaiTugas'] = $this->M_surat_tugas->pegawai_tugas($id_surat);
        $data['tglPelaksanaan'] = $this->db->get_where('tgl_pelaksanaan', ['id_surat' => $id_surat])->result();
        $this->load->view('surat/edit_spt', $data);
    }

    public function proses_editSPT()
    {
        $id_surat = $this->input->post('id_surat');
        $no_surat = $this->input->post('no_surat');
        $dasar_surat = $this->input->post('dasar_surat');
        $kegiatan = $this->input->post('kegiatan');
        $sasaran = $this->input->post('sasaran');
        $indikator = $this->input->post('indikator');
        $rincian_output = $this->input->post('rincian_output');
        $waktu = $this->input->post('waktu');
        $sumber_dana = $this->input->post('sumber_dana');
        $mengetahui = $this->input->post('mengetahui');

        $data = [
            'no_surat' => $no_surat,
            'dasar_surat' => $dasar_surat,
            'kegiatan' => $kegiatan,
            'sasaran' => $sasaran,
            'indikator' => $indikator,
            'rincian_output' => $rincian_output,
            'waktu' => $waktu,
            'sumber_dana' => $sumber_dana,
            'mengetahui' => $mengetahui,
            'modified_at' => date('Y-m-d'),
            'user_input' => $_SESSION['username']
        ];
        $this->db->update('surat', $data, ['id_surat' => $id_surat]);

        $tgl = $this->input->post('tgl_pelaksanaan');
        $tgl2 = implode(',', $tgl); //Pecah dulu array menjadi string karena arraynya kacau
        $tgl3 = explode(',', $tgl2); //Pecah dari string menjadi array

        //Delete tgl_pelaksanaaan lebih dulu
        $this->db->delete('tgl_pelaksanaan', ['id_surat' => $id_surat]);

        for ($i = 0; $i < COUNT($tgl3); $i++) {
            $tgl_pelaksanaan = date('Y-m-d', strtotime($tgl3[$i])); //Ubah menjadi format Y-m-d

            $dataTanggal = [
                'id_surat' => $id_surat,
                'tanggal' => $tgl_pelaksanaan,
            ];
            $this->db->insert('tgl_pelaksanaan', $dataTanggal);
        }

        $petugas = $this->input->post('petugas');
        //Delete pegawai tugas lebih dulu
        $this->db->delete('pegawai_tugas', ['id_surat' => $id_surat]);
        for ($i = 0; $i < COUNT($petugas); $i++) {

            $dataPegawai = [
                'id_surat' => $id_surat,
                'id_pegawai' => $petugas[$i],
            ];
            $this->db->insert('pegawai_tugas', $dataPegawai);
        }
        redirect('Surat_tugas');
    }
}
