<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_surat_tugas extends CI_Model
{
    public function surat_tugas($id_surat = null)
    {
        $this->db->select('*');
        $this->db->from('surat');
        $this->db->join('kegiatan', 'kegiatan.id_kegiatan=surat.kegiatan');
        if ($id_surat != null) {
            $this->db->where('id_surat', $id_surat);
            $query =  $this->db->get();
            return $query->row();
        } else {
            $query =  $this->db->get();
            return $query->result();
        }
    }

    public function cetak_surat($id)
    {
        $this->db->select('*');
        $this->db->from('surat');
        $this->db->join('kegiatan', 'kegiatan.id_kegiatan=surat.kegiatan');
        $this->db->join('pegawai', 'pegawai.id_pegawai=surat.mengetahui');
        $this->db->where(['id_surat' => $id]);
        $query =  $this->db->get();
        return $query->row();
    }

    public function pegawai_tugas($id)
    {
        $this->db->select('*');
        $this->db->from('pegawai_tugas pt');
        $this->db->join('pegawai', 'pegawai.id_pegawai=pt.id_pegawai');
        $this->db->where(['id_surat' => $id]);
        $query =  $this->db->get();
        return $query->result();
    }

    public function insert_surat($data, $id_surat)
    {
        $this->db->update('surat', $data, ['id_surat' => $id_surat]);
        return ($this->db->affected_rows() > 0) ? true : false;
    }
}
